<footer class="main-footer">
	
	<strong>Copyright &copy; 2020 <a href="#" target="_blank">Desarrollado por Equipo Prodysa</a></strong>

	Todos los derechos reservados.


</footer>