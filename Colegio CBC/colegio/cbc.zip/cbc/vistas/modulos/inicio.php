<div class="content-wrapper">

  <section class="content-header">
    <center>
    <h3>
      
    Avisos del Departamento de Registro y Control Escolar
      
     
    
    </h3>
</center>
    <ol class="breadcrumb">
      
      <li><a href="inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      
      <li class="active">Tablero</li>
    
    </ol>

  </section>

  <section class="content">

    <div class="row">
      
    <?php

    if($_SESSION["perfil"] =="Administrador"){

      include "inicio/cajas-superiores.php";

    }

    ?>

    </div> 

     <div class="row">
       
        

        
     </div>

  </section>
 
</div>
